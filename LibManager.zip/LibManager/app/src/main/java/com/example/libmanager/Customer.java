package com.example.libmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Customer extends AppCompatActivity {

    private Button Logout;
    private Button ViewRented;
    private Button ViewAll;
    private Button Notification;
    private TextView Info;
    private EditText username;
    SQLiteDatabase db;
    SharedPreferences sharedpreferences;
    String session_username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);

        Logout = findViewById(R.id.btnLogout_Customer);
        ViewAll = findViewById(R.id.btnViewAll_Customer);
        ViewRented = findViewById(R.id.btnViewRented_Customer);
        Notification = findViewById(R.id.btnNotifications_Customer);
        Info = findViewById(R.id.tvInfo_Customer);

        db = openOrCreateDatabase("LibManager", Context.MODE_PRIVATE, null);
        sharedpreferences = getSharedPreferences("shared_prefs", Context.MODE_PRIVATE);
        session_username = sharedpreferences.getString("username", null);
        Info.setText("Your Username is " + session_username);

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.clear();
                editor.apply();
                Intent intent = new Intent(Customer.this, MainActivity.class);
                startActivity(intent);
            }
        });

        ViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor C = db.rawQuery("SELECT * FROM books",null);
                if (C.getCount() == 0){
                    showMessage("All Books", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while (C.moveToNext()){
                    buffer.append("Book ID: "+C.getString(0)+"\n");
                    buffer.append("Book Name: "+C.getString(1)+"\n");
                    buffer.append("Book Author: "+C.getString(2)+"\n");
                    buffer.append("Status: "+C.getString(3)+"\n\n");
                }
                showMessage("All Books", buffer.toString());
            }
        });

        ViewRented.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor C = db.rawQuery("SELECT books.id, books.name, books.author, rented.duedate FROM rented, books WHERE rented.uname = '" + session_username + "' AND rented.id=books.id", null);
                if (C.getCount() == 0){
                    showMessage("Rented Books", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while (C.moveToNext()){
                    buffer.append("Book ID: "+C.getString(0)+"\n");
                    buffer.append("Book Name: "+C.getString(1)+"\n");
                    buffer.append("Book Author: "+C.getString(2)+"\n");
                    buffer.append("Due Date: "+C.getString(3)+"\n\n");
                }
                showMessage("Rented Books", buffer.toString());
            }
        });

        Notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //2021-04-14
                String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                Cursor C = db.rawQuery("SELECT books.id, books.name, books.author, rented.duedate FROM rented,books WHERE rented.uname='" + session_username + "' AND rented.id=books.id AND rented.duedate='"+date+"'", null);
                if (C.getCount() == 0){
                    showMessage("Notifications", "No notifications");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while (C.moveToNext()){
                    buffer.append("The following book(s) deadline for submission is today. Please do so by midnight to avoid a fine.\n");
                    buffer.append("Book ID: "+C.getString(0)+"\n");
                    buffer.append("Book Name: "+C.getString(1)+"\n");
                    buffer.append("Book Author: "+C.getString(2)+"\n");
                    buffer.append("Due Date: "+C.getString(3)+"\n\n");
                }
                showMessage("Notifications", buffer.toString());
            }
        });
    }
    public void showMessage(String title, String message){
        Builder builder=new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}