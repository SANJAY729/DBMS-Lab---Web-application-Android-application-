package com.example.libmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.widget.Toast;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class Librarian extends AppCompatActivity {

    private EditText modify_bookId;
    private EditText rent_bookId;
    private EditText bookName;
    private EditText bookAuthor;
    private EditText customerUsername;
    private Button Logout;
    private Button Add;
    private Button Delete;
    private Button DueDate;
    private Button Loan;
    private Button Receive;
    private Button ViewRented;
    private Button ViewAll;
    SQLiteDatabase db;
    SharedPreferences sharedpreferences;
    String session_username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian);

        modify_bookId = findViewById(R.id.etId_Librarian);
        rent_bookId = findViewById(R.id.etId_Librarian2);
        bookName = findViewById(R.id.etBookName_Librarian);
        bookAuthor = findViewById(R.id.etBookAuthor_Librarian);
        customerUsername = findViewById(R.id.etCustomerUsername_Librarian);

        Logout = findViewById(R.id.btnLogout_Librarian);
        Add = findViewById(R.id.btnAddBook_Librarian);
        Delete = findViewById(R.id.btnDeleteBook_Librarian);
        DueDate = findViewById(R.id.btnDueDate_Librarian);
        Loan = findViewById(R.id.btnLoanBook_Librarian);
        Receive = findViewById(R.id.btnReceiveBook_Librarian);
        ViewRented = findViewById(R.id.btnViewRented_Librarian);
        ViewAll = findViewById(R.id.btnViewAll_Librarian);

        db = openOrCreateDatabase("LibManager", Context.MODE_PRIVATE, null);
        sharedpreferences = getSharedPreferences("shared_prefs", Context.MODE_PRIVATE);
        session_username = sharedpreferences.getString("username", null);

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.clear();
                editor.apply();
                Intent intent = new Intent(Librarian.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (modify_bookId.getText().toString().trim().length() == 0 ||
                        bookName.getText().toString().trim().length() == 0 ||
                        bookAuthor.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all fields");
                    return;
                }
                Cursor C = db.rawQuery("SELECT * FROM books WHERE id='" + modify_bookId.getText() + "'", null);
                if (!C.moveToFirst()) {
                    db.execSQL("INSERT INTO books VALUES('" + modify_bookId.getText() + "','" + bookName.getText() + "','" + bookAuthor.getText() + "','Available');");
                    showMessage("Success", "New Book Added");
                } else
                    Toast.makeText(Librarian.this, "ID already present", Toast.LENGTH_SHORT).show();
            }
        });

        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (modify_bookId.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all fields");
                    return;
                }
                Cursor C = db.rawQuery("SELECT * FROM books WHERE id='" + modify_bookId.getText() + "'", null);
                if (C.moveToFirst()) {
                    db.execSQL("DELETE FROM books WHERE id='" + modify_bookId.getText() + "';");
                    showMessage("Success", "Book Deleted");
                } else
                    Toast.makeText(Librarian.this, "ID does not exist", Toast.LENGTH_SHORT).show();
            }
        });

        MaterialDatePicker.Builder builderDate = MaterialDatePicker.Builder.datePicker();
        builderDate.setTitleText("SELECT A DUE DATE");
        final MaterialDatePicker materialDatePicker = builderDate.build();
        final String[] selectedDueDate = {""};

        DueDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDatePicker.show(getSupportFragmentManager(), "DATE_PICKER");
            }
        });

        materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener<Long>() {
            @Override
            public void onPositiveButtonClick(Long selection) {
                TimeZone timeZoneUTC = TimeZone.getDefault();
                int offsetFromUTC = timeZoneUTC.getOffset(new Date().getTime()) * -1;
                SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                Date date = new Date(selection + offsetFromUTC);
                selectedDueDate[0] = simpleFormat.format(date);
            }
        });

        Loan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rent_bookId.getText().toString().trim().length() == 0 || customerUsername.getText().toString().trim().length() == 0 || selectedDueDate[0].length() < 2) {
                    showMessage("Error", "Please enter all fields");
                    return;
                }
                Cursor C = db.rawQuery("SELECT * FROM books WHERE id='" + rent_bookId.getText() + "' AND status='Available'", null);
                if (C.moveToFirst()) {
                    C = db.rawQuery("SELECT * FROM customers WHERE uname='" + customerUsername.getText() + "'", null);
                    if (C.moveToFirst()) {
                        db.execSQL("INSERT INTO rented VALUES('"+customerUsername.getText()+"','"+rent_bookId.getText()+"','"+selectedDueDate[0]+"');");
                        db.execSQL("UPDATE books SET status='Rented' WHERE id='" + rent_bookId.getText() + "'");
                        Toast.makeText(Librarian.this, "Book Loaned Successfully", Toast.LENGTH_SHORT).show();
                    } else
                        Toast.makeText(Librarian.this, "Username does not exist", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(Librarian.this, "Book Unavailable or Does not exist", Toast.LENGTH_SHORT).show();
            }
        });

        Receive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rent_bookId.getText().toString().trim().length() == 0 || customerUsername.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all fields");
                    return;
                }
                Cursor C = db.rawQuery("SELECT * FROM books WHERE id='" + rent_bookId.getText() + "' AND status='Rented'", null);
                if (C.moveToFirst()) {
                    C = db.rawQuery("SELECT * FROM customers WHERE uname='" + customerUsername.getText() + "'", null);
                    if (C.moveToFirst()) {
                        C = db.rawQuery("SELECT duedate FROM rented WHERE uname='" + customerUsername.getText() + "' AND id='" + rent_bookId.getText() + "';", null);
                        if (C.moveToFirst()) {
                            Date Deadline = null;
                            try {
                                Deadline = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).parse(C.getString(0));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date Today = null;
                            try {
                                Today = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).parse(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            if (Deadline.compareTo(Today) < 0)
                                showMessage("Fine", "Fine to be levied on Customer for late return");
                            db.execSQL("DELETE FROM rented WHERE uname='" + customerUsername.getText() + "' AND id='" + rent_bookId.getText() + "';");
                            db.execSQL("UPDATE books SET status='Available' WHERE id='" + rent_bookId.getText() + "'");
                            Toast.makeText(Librarian.this, "Book Received Successfully", Toast.LENGTH_SHORT).show();
                        } else
                            Toast.makeText(Librarian.this, "This Username has not rented this book", Toast.LENGTH_SHORT).show();
                    } else
                        Toast.makeText(Librarian.this, "Username does not exist", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(Librarian.this, "ID does not exist", Toast.LENGTH_SHORT).show();
            }
        });

        ViewRented.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor C = db.rawQuery("SELECT * FROM rented", null);
                if (C.getCount() == 0) {
                    showMessage("Rented Books", "No records found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (C.moveToNext()) {
                    buffer.append("Customer Username: " + C.getString(0) + "\n");
                    buffer.append("Book ID: " + C.getString(1) + "\n");
                    buffer.append("Due Date: " + C.getString(2) + "\n\n");
                }
                showMessage("Rented Books", buffer.toString());
            }
        });

        ViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor C = db.rawQuery("SELECT * FROM books", null);
                if (C.getCount() == 0) {
                    showMessage("Books", "No records found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (C.moveToNext()) {
                    buffer.append("Book ID: " + C.getString(0) + "\n");
                    buffer.append("Book Name: " + C.getString(1) + "\n");
                    buffer.append("Book Author: " + C.getString(2) + "\n");
                    buffer.append("Status: " + C.getString(3) + "\n\n");
                }
                showMessage("Books", buffer.toString());
            }
        });
    }

    public void showMessage(String title, String message){
        Builder builder=new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}