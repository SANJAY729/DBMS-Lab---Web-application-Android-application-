package com.example.libmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText Username;
    private EditText Password;
    private Button Login;
    private Button SignUp;
    SQLiteDatabase db;
    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = findViewById(R.id.etUsername);
        Password = findViewById(R.id.etPassword);
        Login = findViewById(R.id.btnLogin);
        SignUp = findViewById((R.id.btnSignUp));

        db = openOrCreateDatabase("LibManager", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS customers(uname VARCHAR, pwd VARCHAR, name VARCHAR, phno INT);");
        db.execSQL("CREATE TABLE IF NOT EXISTS books(id INT, name VARCHAR, author VARCHAR, status VARCHAR default 'Available');");
        db.execSQL("CREATE TABLE IF NOT EXISTS rented(uname VARCHAR, id INT, duedate datetime);");
        db.execSQL("CREATE TABLE IF NOT EXISTS librarians(uname VARCHAR, pwd VARCHAR, name VARCHAR, phno INT);");

        sharedpreferences = getSharedPreferences("shared_prefs", Context.MODE_PRIVATE);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Username.getText().toString().trim().length()==0 || Password.getText().toString().trim().length()==0){
                    showMessage("Error", "Please enter all fields");
                    return;
                }
                Cursor c = db.rawQuery("SELECT * FROM customers WHERE uname='"+Username.getText()+"' AND pwd='"+Password.getText()+"'", null);
                if (c.moveToFirst()){
                    Toast.makeText(MainActivity.this, "Login was successful", Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("username", Username.getText().toString());
                    editor.apply();
                    Intent intent = new Intent(MainActivity.this, Customer.class);
                    startActivity(intent);
                } else {
                    c = db.rawQuery("SELECT * FROM librarians WHERE uname='"+Username.getText()+"' AND pwd='"+Password.getText()+"'", null);
                    if (c.moveToFirst()){
                        SharedPreferences.Editor editor = sharedpreferences.edit();
                        editor.putString("username", Username.getText().toString());
                        editor.apply();
                        Toast.makeText(MainActivity.this, "Login was successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, Librarian.class);
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this, SignUp.class);
                startActivity(intent);
            }
        });
    }

    public void showMessage(String title, String message){
        Builder builder=new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}