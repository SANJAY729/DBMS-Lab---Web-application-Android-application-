package com.example.libmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;


public class SignUp extends AppCompatActivity {

    private EditText Username;
    private EditText Password;
    private EditText Confirm_Password;
    private EditText Name;
    private EditText PhoneNo;
    private Button Login;
    private Button SignUp;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Username = findViewById(R.id.etUsername_SignUp);
        Password = findViewById(R.id.etPassword_SignUp);
        Confirm_Password = findViewById((R.id.etConfirmPassword_SignUp));
        Name = findViewById(R.id.etName_SignUp);
        PhoneNo = findViewById(R.id.etPhone_SignUp);
        Login = findViewById(R.id.btn_Login_SignUp);
        SignUp = findViewById(R.id.btn_SignUp_SignUp);

        db = openOrCreateDatabase("LibManager", Context.MODE_PRIVATE, null);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (SignUp.this, MainActivity.class);
                startActivity(intent);
            }
        });

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Username.getText().toString().trim().length()==0 ||
                        Password.getText().toString().trim().length()==0 ||
                        Confirm_Password.getText().toString().trim().length()==0 ||
                        Name.getText().toString().trim().length()==0 ||
                        PhoneNo.getText().toString().trim().length()==0){
                    showMessage("Error", "Please enter all fields");
                    return;
                }
                if (!Password.getText().toString().trim().equals(Confirm_Password.getText().toString().trim())) {
                    showMessage("Error", "Please confirm your password correctly");
                    return;
                }
                Cursor c = db.rawQuery("SELECT * FROM customers WHERE uname='"+Username.getText()+"'", null);
                if (c.moveToFirst())
                    Toast.makeText(SignUp.this, "Username already taken", Toast.LENGTH_SHORT).show();
                else {
                    c = db.rawQuery("SELECT * FROM librarians WHERE uname='"+Username.getText()+"'", null);
                    if (!c.moveToFirst()) {
                        db.execSQL("INSERT INTO customers VALUES('"+Username.getText()+"','"+Password.getText()+"','"+Name.getText()+"','"+PhoneNo.getText()+"');");
                        showMessage("Success", "New User Created");
                    } else
                        Toast.makeText(SignUp.this, "Username already taken", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void showMessage(String title, String message){
        Builder builder=new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}